import json
from audit import HashChainAudit

def test_audit_detects_tampering(tmp_path):
    path = tmp_path / "audit.jsonl"
    audit = HashChainAudit(path)
    audit.append({"decision": "APPROVE"})
    audit.append({"decision": "BLOCK"})
    assert audit.verify()["valid"]
    rows = path.read_text().splitlines()
    first = json.loads(rows[0])
    first["record"]["decision"] = "BLOCK"
    rows[0] = json.dumps(first)
    path.write_text("\n".join(rows) + "\n")
    assert not audit.verify()["valid"]
